﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Eventing.Reader;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;


public class todo_list
{
    public string name { get; set; }
    public string status { get; set; }

}

public class Program
{

    public static List<todo_list> ToDo = new List<todo_list>();

    static void Main(string[] args)
    {

        ShowOptions();
    }

    public static void ShowOptions()
    {
        Console.WriteLine();
        Console.WriteLine("Hier siehst du die Übersicht was du alles machen kannst: ");
        Console.WriteLine("1. Siehe dir deine To-Do-Liste an.");
        Console.WriteLine("2. Füge etwas zu deiner To-Do-Liste hinzu.");
        Console.WriteLine("3. Lösche etwas aus deiner To-Do-Liste.");
        Console.WriteLine("4. Verändere den Status von etwas in deiner To-Do-Liste.");
        Console.WriteLine();
        Console.Write("Bitte wähle eine Option aus: ");
        string option = Console.ReadLine();
        SelectedOption(option);

    }

    public static void SelectedOption(string option)
    {
        if (option == "1")
        {
            Console.Clear();
            Console.WriteLine("Deine aktuelle To-Do-Liste: ");
            Console.WriteLine();

            if (ToDo.Count == 0)
            {
                Console.WriteLine("Die To-Do-Liste ist leer.");
            }
            else
            {
                // Sortiere die Liste alphabetisch nach 'name'
                var sortedToDoList = ToDo.OrderBy(item => item.name).ToList();

                foreach (var item in sortedToDoList)
                {
                    Console.WriteLine($"Name: {item.name} | Status: {item.status}");
                }
            }

            ShowOptions();
        }
        else if (option == "2")
        {
            Console.Clear();
            Console.Write("Bitte gebe ein was du für ein Ziel hast: ");
            string ziel_name = Console.ReadLine();

            todo_list todo = new todo_list();
            todo.name = ziel_name;
            todo.status = "Nicht erledigt";

            ToDo.Add(todo);
            ShowOptions();
        }
        else if (option == "3")
        {
            Console.Clear();
            Console.Write("Bitte gebe an was du löschen möchtest: ");
            string ziel_name = Console.ReadLine();

            todo_list itemToRemove = null;

            foreach (var item in ToDo)
            {
                if (item.name == ziel_name)
                {
                    itemToRemove = item;
                    break;
                }
            }

            if (itemToRemove != null)
            {
                ToDo.Remove(itemToRemove);
                Console.WriteLine($"Das To-Do '{ziel_name}' wurde gelöscht.");
            }
            else
            {
                Console.WriteLine($"Kein To-Do mit dem Namen '{ziel_name}' gefunden.");
            }

            ShowOptions();
        }
        else if (option == "4")
        {
            Console.Clear();
            Console.Write("Bitte gebe an welchen Status du ändern möchtest: ");
            string ziel_name = Console.ReadLine();
            Console.Write("Bitte gebe an wie du den Status setzen möchtest: ");
            string ziel_status = Console.ReadLine();

            todo_list itemToEdit = null;

            foreach (var item in ToDo)
            {
                if (item.name == ziel_name)
                {
                    itemToEdit = item;
                    break;
                }
            }

            if (itemToEdit != null)
            {
                itemToEdit.status = ziel_status;
                Console.WriteLine($"Das To-Do '{ziel_name}' wurde geändert zu {ziel_status}.");
            }
            else
            {
                Console.WriteLine($"Kein To-Do mit dem Namen '{ziel_name}' gefunden.");
            }

            ShowOptions();
        }
    }


}