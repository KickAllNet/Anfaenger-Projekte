﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class Program
{
    static void Main(string[] args)
    {
        Random rnd = new Random();
        int zahl = rnd.Next(1, 10);

        GiveATry(zahl);
    }

    public static void GiveATry(int zahl)
    {
        Console.Write("Gebe eine Zahl ein: ");
        string eingabe_zahl = Console.ReadLine();
        Check(eingabe_zahl, zahl);
    }

    public static void Check(string eingabe_zahl, int zahl)
    {
        if (Convert.ToInt32(eingabe_zahl) < zahl)
        {
            Console.WriteLine("Zu niedrig");
            GiveATry(zahl);
        }
        else if (Convert.ToInt32(eingabe_zahl) > zahl)
        {
            Console.WriteLine("Zu hoch");
            GiveATry(zahl);
        }
        else if (Convert.ToInt32(eingabe_zahl) == zahl)
        {
            Console.WriteLine($"Richtig du hast gewonnen, die gesuchte Zahl war {zahl}.");
        }
    }
}