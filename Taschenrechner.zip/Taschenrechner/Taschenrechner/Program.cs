﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class Program
{
    static void Main()
    {
        GiveATry();
    }

    public static void GiveATry()
    {
        Console.Write("Bitte gebe die erste Zahl an: ");
        string zahl1 = Console.ReadLine();
        Console.Write("Bitte gebe die zweite Zahl an: ");
        string zahl2 = Console.ReadLine();
        Console.Write("Bitte gebe an was du rechen möchtest. (+, -, *, /): ");
        string option = Console.ReadLine();
        if (zahl1 == "")
        {
            GiveATry();
        }
        if (zahl2 == "")
        {
            GiveATry();
        }
        if (option == "")
        {
            GiveATry();
        }
        EndSum(Convert.ToInt32(zahl1), Convert.ToInt32(zahl2), option);

    }

    public static void EndSum(int zahl1, int zahl2, string option)
    {
        if (option == "+")
        {
            int ergebniss = zahl1 + zahl2;
            Console.WriteLine($"Das Ergebnis ist: {ergebniss}");
            GiveATry();
        }
        if (option == "-")
        {
            int ergebniss = zahl1 - zahl2;
            Console.WriteLine($"Das Ergebnis ist: {ergebniss}");
            GiveATry();
        }
        if (option == "*")
        {
            int ergebniss = zahl1 * zahl2;
            Console.WriteLine($"Das Ergebnis ist: {ergebniss}");
            GiveATry();
        }
        if (option == "/")
        {
            int ergebniss = zahl1 / zahl2;
            Console.WriteLine($"Das Ergebnis ist: {ergebniss}");
            GiveATry();
        }
    }
}